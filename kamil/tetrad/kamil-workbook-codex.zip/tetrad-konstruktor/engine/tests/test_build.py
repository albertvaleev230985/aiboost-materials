import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from xml.etree import ElementTree

from PIL import Image

from engine.build import BuildError, build, read_tokens
from engine.render import ROOT


class BuildTest(unittest.TestCase):
    def setUp(self):
        scratch = tempfile.TemporaryDirectory(prefix="test-", dir=ROOT)
        self.addCleanup(scratch.cleanup)
        self.root = Path(scratch.name)
        self.book = self.root / "source"
        (self.book / "chapters").mkdir(parents=True)
        self.chapter = self.book / "chapters" / "01.json"
        self.out = self.root / "export"

    def write_book(self, pages, fmt="A4"):
        (self.book / "book.json").write_text(json.dumps({
            "format": fmt,
            "title": "Проверка тетради",
        }), encoding="utf-8")
        self.chapter.write_text(json.dumps({
            "title": "Первая встреча",
            "pages": pages,
        }), encoding="utf-8")

    def test_page_count_trim_font_and_preview(self):
        self.write_book([
            {"t": "cover", "title": "Проверка", "emblem": "mark"},
            {"t": "page", "blocks": [
                {"b": "p", "text": "Кириллица. Ёж в чаще."},
                {"b": "lines", "n": "fill"},
            ]},
        ])
        tokens = read_tokens()
        result = build(self.book, self.out, tokens, print_mode=True)
        self.assertEqual(result.pages, 2)
        boxes = subprocess.check_output(["pdfinfo", "-box", str(self.out / "book.pdf")], text=True)
        self.assertRegex(boxes, r"TrimBox:\s+0\.00\s+0\.00\s+595\.28\s+841\.89")
        self.assertRegex(boxes, r"BleedBox:\s+-8\.50\s+-8\.50")
        self.assertTrue((self.out / "sheet-01.jpg").is_file())
        self.assertFalse(result.warnings)

    def test_a5_notes_grid_respects_body(self):
        self.write_book([{"t": "notes", "style": "dots"}], fmt="A5")
        result = build(self.book, self.out, read_tokens())
        self.assertEqual(result.pages, 1)

    def test_opener_without_kicker(self):
        self.write_book([{"t": "opener", "title": "Фокус"}])
        self.assertEqual(build(self.book, self.out, read_tokens()).pages, 1)

    def test_overflow_does_not_replace_previous_pdf(self):
        self.write_book([{"blocks": [{"b": "p", "text": "Текст для проверки."}]}])
        build(self.book, self.out, read_tokens())
        prior = (self.out / "book.pdf").read_bytes()
        self.write_book([{"blocks": [
            {"b": "questions", "items": [{"q": "Где текст?", "lines": 50}]},
        ]}])
        with self.assertRaisesRegex(BuildError, r"01\.json.*переполнение"):
            build(self.book, self.out, read_tokens())
        self.assertEqual((self.out / "book.pdf").read_bytes(), prior)

    def test_header_overflow_is_reported(self):
        self.write_book([{"blocks": [], "band_title": "Длинный заголовок " * 45}])
        with self.assertRaisesRegex(BuildError, r"01\.json.*переполнение"):
            build(self.book, self.out, read_tokens())

    def test_cover_and_footer_collisions_are_reported(self):
        self.write_book([{
            "t": "cover", "title": "Первая\nВторая\nТретья\nЧетвёртая",
            "subtitle": "Рабочая тетрадь",
        }])
        with self.assertRaisesRegex(BuildError, "переполнение"):
            build(self.book, self.out, read_tokens())

        self.write_book([{"blocks": []}])
        book_file = self.book / "book.json"
        book = json.loads(book_file.read_text())
        book["footer"] = "Длинное название " * 40
        book_file.write_text(json.dumps(book))
        with self.assertRaisesRegex(BuildError, "переполнение"):
            build(self.book, self.out, read_tokens())

    def test_malformed_page_and_block_fields_are_reported(self):
        for page in (
            {"blocks": {}},
            {"blocks": [{"b": "list", "items": "Проверка"}]},
            {"blocks": [{"b": "questions", "items": [{"q": "Ответ?", "lines": -3}]}]},
            {"t": "tracker", "days": 0},
        ):
            with self.subTest(page=page):
                self.write_book([page])
                with self.assertRaisesRegex(BuildError, r"01\.json"):
                    build(self.book, self.out, read_tokens())

    def test_crop_marks_are_visible_outside_bleed_on_dark_pages(self):
        self.write_book([{"t": "cover", "title": "Проверка"}, {"t": "back"}])
        build(self.book, self.out, read_tokens(), print_mode=True, marks=True)
        pdf = self.out / "book.pdf"
        boxes = subprocess.check_output(["pdfinfo", "-box", str(pdf)], text=True)
        self.assertRegex(boxes, r"MediaBox:\s+-19\.84\s+-19\.84")
        self.assertRegex(boxes, r"BleedBox:\s+-8\.50\s+-8\.50")
        prefix = self.root / "raster"
        subprocess.run(["pdftoppm", "-r", "144", "-png", str(pdf), str(prefix)], check=True)
        for page in (1, 2):
            with Image.open(prefix.with_name(f"raster-{page}.png")) as rendered:
                raster = rendered.convert("RGB")
                for y in (40, raster.height - 40):
                    for x in (15, raster.width - 15):
                        area = raster.crop((x - 3, y - 3, x + 3, y + 3))
                        self.assertTrue(any(max(rgb) < 100 for rgb in area.get_flattened_data()))

    def test_marks_require_a_supported_bleed(self):
        self.write_book([{"t": "notes"}])
        tokens = read_tokens()
        for bleed in (0, 4):
            with self.subTest(bleed=bleed):
                tokens["print"]["bleed"] = bleed
                with self.assertRaisesRegex(BuildError, "вылет"):
                    build(self.book, self.out, tokens, print_mode=True, marks=True)

    def test_publishing_preserves_unknown_files_and_recovers_backup(self):
        self.write_book([{"t": "notes"}])
        tokens = read_tokens()
        build(self.book, self.out, tokens)
        backup = self.out.with_name(".export.previous")
        self.out.rename(backup)
        note = backup / "my-notes.txt"
        note.write_text("keep")
        with self.assertRaisesRegex(BuildError, "my-notes.txt"):
            build(self.book, self.out, tokens)
        self.assertTrue((self.out / "book.pdf").is_file())
        self.assertEqual((self.out / note.name).read_text(), "keep")

    def test_table_and_field_text_stay_in_their_slots(self):
        self.write_book([{"blocks": [
            {"b": "table", "cols": [
                {"title": "Тема", "w": 1},
                {"title": "Шаг", "w": 2},
                {"title": "Дата", "w": 3},
            ], "rows": [["Самосовершенствование", "Позвонить", "В пятницу"]]},
            {"b": "fields", "items": [
                {"label": "Первое поле"},
                {"label": "Следующая строка\nс уточнением\nи третья строка", "lines": 2},
            ]},
        ]}])
        build(self.book, self.out, read_tokens())
        bbox = subprocess.check_output(["pdftotext", "-bbox", str(self.out / "book.pdf"), "-"], text=True)
        words = {
            word.text: {key: float(value) for key, value in word.attrib.items()}
            for word in ElementTree.fromstring(bbox).findall(".//{*}word")
        }
        self.assertLess(words["Первое"]["yMax"], words["Следующая"]["yMin"])
        first_cell = [box for word, box in words.items() if word in "Самосовершенствование" and len(word) > 2]
        self.assertTrue(first_cell)
        self.assertTrue(all(box["xMax"] < words["Позвонить"]["xMin"] for box in first_cell))

    def test_long_contents_item_stays_below_heading(self):
        self.write_book([{"t": "contents"}], fmt="A5")
        (self.chapter.with_name("02.json")).write_text(json.dumps({
            "title": "Теория",
            "toc_title": "Длинное название раздела чтобы понять как распределяется текст по полям между строками содержания когда в названии оказывается много слов и приходится переносить текст несколько раз",
            "pages": [{"blocks": []}],
        }))
        build(self.book, self.out, read_tokens())
        bbox = subprocess.check_output(["pdftotext", "-f", "1", "-l", "1", "-bbox",
                                        str(self.out / "book.pdf"), "-"], text=True)
        words = {word.text: word for word in ElementTree.fromstring(bbox).findall(".//{*}word")}
        self.assertLess(float(words["Содержание"].get("yMax")), float(words["Длинное"].get("yMin")))

    def test_path_escape_and_missing_glyph_are_reported(self):
        self.write_book([{"blocks": [
            {"b": "p", "text": "Стрелка →"},
            {"b": "image", "src": "/etc/hosts", "h_mm": 10},
        ]}])
        with self.assertRaises(BuildError) as result:
            build(self.book, self.out, read_tokens())
        self.assertIn("картинка", str(result.exception))
        self.assertIn("U+2192", str(result.exception))

    def test_empty_chapter_does_not_create_blank_pdf(self):
        self.write_book([])
        with self.assertRaisesRegex(BuildError, "нет страниц"):
            build(self.book, self.out, read_tokens())

    def test_successive_builds_remove_obsolete_sheets(self):
        self.write_book([{"t": "notes"}] * 13)
        build(self.book, self.out, read_tokens())
        self.assertTrue((self.out / "sheet-02.jpg").is_file())
        self.write_book([{"t": "notes"}])
        build(self.book, self.out, read_tokens())
        self.assertFalse((self.out / "sheet-02.jpg").exists())
