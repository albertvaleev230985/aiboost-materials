import json
import tempfile
import unittest
from pathlib import Path

from weasyprint import HTML

from engine.render import ROOT
from engine.tools import ToolError, install_skill, scan


class ToolsTest(unittest.TestCase):
    def setUp(self):
        scratch = tempfile.TemporaryDirectory(prefix="test-", dir=ROOT)
        self.addCleanup(scratch.cleanup)
        self.root = Path(scratch.name)

    def test_scan_makes_numbered_pages_sheets_and_index(self):
        pdf = self.root / "old.pdf"
        pages = "".join('<p style="break-after:page">Страница %d</p>' % n for n in range(1, 15))
        HTML(string="<style>@page{size:210mm 297mm}</style>" + pages).write_pdf(pdf)
        dest, index = scan(pdf, "proba", books=self.root / "books", resolution=30)
        self.assertEqual(index["pages"], 14)
        self.assertEqual(index["page_mm"], [210, 297])
        self.assertEqual(len(list(dest.glob("p-*.jpg"))), 14)
        self.assertTrue((dest / "p-001.jpg").is_file() and (dest / "p-014.jpg").is_file())
        self.assertEqual(len(list(dest.glob("sheet-*.jpg"))), 2)
        self.assertEqual(json.loads((dest / "index.json").read_text(encoding="utf-8"))["pdf"], "old.pdf")
        # повторный запуск не оставляет лишних страниц
        short = self.root / "short.pdf"
        HTML(string="<p>Одна</p>").write_pdf(short)
        dest, index = scan(short, "proba", books=self.root / "books", resolution=30)
        self.assertEqual(len(list(dest.glob("p-*.jpg"))), 1)
        self.assertEqual(len(list(dest.glob("sheet-*.jpg"))), 1)

    def test_scan_rejects_bad_name_and_missing_file(self):
        with self.assertRaises(ToolError):
            scan(self.root / "нет.pdf", "proba", books=self.root / "books")
        with self.assertRaises(ToolError):
            scan(self.root / "нет.pdf", "../plohoe imya", books=self.root / "books")

    def test_skill_points_to_this_project(self):
        path = install_skill(self.root / "skills")
        text = path.read_text(encoding="utf-8")
        self.assertEqual(path.parent.name, "workbook-kamil")
        self.assertIn(str(ROOT), text)
        self.assertTrue(text.startswith("---\nname: workbook-kamil\n"))


if __name__ == "__main__":
    unittest.main()
