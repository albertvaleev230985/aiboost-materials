"""Шаблоны тетради: из описания страниц (JSON) получается HTML.

Здесь живут все виды страниц (T_*) и все блоки (B_*). Агент, который пишет
тетрадь, этот файл не трогает: он правит только JSON в books/<тетрадь>/.
Новый блок или страница добавляются сюда по прямой команде «меняем конструктор».
"""
import html
import json
import math
import re
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parent.parent
MAX_FILL_ROWS = 60
SHORT = ("в", "и", "к", "с", "о", "у", "а", "я", "на", "по", "не", "за", "из", "от", "до", "но",
         "во", "со", "ко", "об", "ли", "же", "бы", "ни", "да", "то", "их", "ее", "её", "его", "для", "или", "что", "как", "при", "без", "над", "под", "про")


class Problem(Exception):
    pass


class Ctx:
    """Всё, что нужно шаблонам во время сборки одной тетради."""

    def __init__(self, book, book_dir, tokens):
        self.book = book
        self.book_dir = book_dir
        self.tokens = tokens
        self.fmt = tokens["formats"][book["format"]]
        self.errors = []      # (где, что)
        self.warnings = []
        self.where = ""       # «chapters/01.json, страница 3»
        self.page_no = 0
        self.side = "recto"
        self.block_ids = []   # id блоков текущей страницы
        self.pages_ids = {}   # номер страницы -> список id блоков
        self.page_where = {}  # номер страницы -> где описана
        self.images = []      # (путь, ширина, высота, вписывание, место)
        self.chars = {}       # символ → страницы
        self.toc = []
        self._bn = 0

    def err(self, msg):
        self.errors.append((self.where, msg))

    def warn(self, msg):
        self.warnings.append((self.where, msg))

    def bid(self):
        self._bn += 1
        i = "b-%03d-%02d" % (self.page_no, self._bn)
        self.block_ids.append(i)
        return i

    def body_w(self):
        f = self.fmt
        return f["page-w"] - f["m-inner"] - f["m-outer"]

    def body_h(self, full=False):
        f = self.fmt
        return f["page-h"] - (f["m-outer"] if full else f["body-top"]) - f["body-bottom"]


# ---------- текст ----------

def esc(ctx, text):
    """Экранирует текст, понимает **жирный** и перенос строки, клеит короткие слова к следующему."""
    if text is None:
        return ""
    if not isinstance(text, str):
        text = str(text)
    for char in text:
        ctx.chars.setdefault(char, set()).add(ctx.page_no)
    s = html.escape(text, quote=False)
    s = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", s)
    s = re.sub(r"(?<![\w-])(%s) (?=\S)" % "|".join(SHORT), lambda m: m.group(1) + " ", s, flags=re.I)
    s = s.replace(" – ", " – ")
    return s.replace("\n", "<br>")


def mm(v):
    return ("%.2f" % v).rstrip("0").rstrip(".") + "mm"


def check_keys(ctx, d, name, required, optional=()):
    if not isinstance(d, dict):
        raise ValueError(f"{name}: нужен объект")
    ok = True
    for k in required:
        if k not in d:
            ctx.err("в «%s» нет обязательного поля «%s»" % (name, k))
            ok = False
    known = set(required) | set(optional) | {"b", "t", "_"}
    for k in d:
        if k not in known:
            ctx.warn("в «%s» лишнее поле «%s», оно не используется (опечатка?)" % (name, k))
    return ok


# ---------- мелкая графика ----------

def svg_arrow():
    return ('<svg class="goal-arrow" viewBox="0 0 18 8"><path d="M1 4h14" stroke="currentColor" stroke-width="0.9" fill="none"/>'
            '<path d="M11.5 0.8 16.6 4l-5.1 3.2z" fill="currentColor"/></svg>')


def svg_note():
    return ('<svg class="note-i" viewBox="0 0 14 14"><circle cx="7" cy="7" r="6.2" fill="none" stroke="#1D5E40" stroke-width="0.9"/>'
            '<circle cx="7" cy="3.9" r="0.95" fill="#1D5E40"/><path d="M7 6.1v4.6" stroke="#1D5E40" stroke-width="1.5" stroke-linecap="round"/></svg>')


def array(value, label):
    if not isinstance(value, list):
        raise ValueError(f"{label}: нужен список")
    return value


def count(value, label, low=1, high=MAX_FILL_ROWS):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f"{label}: нужно целое число от {low} до {high}")
    return value


def svg_wheel(ctx, n, rings, size):
    """Круг со шкалой и номерами. Длинные подписи размещаются в легенде."""
    fs = ctx.fmt["fs-small"] * 0.3528
    r = size / 2 - 7
    cx = cy = size / 2
    o = ['<svg width="%s" height="%s" viewBox="0 0 %.2f %.2f">' % (mm(size), mm(size), size, size)]
    for i in range(1, rings + 1):
        w = 0.34 if i in (rings, rings // 2) else 0.16
        o.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="none" stroke="#8C8C8C" stroke-width="%.2f"/>' % (cx, cy, r * i / rings, w))
    for k in range(n):
        a = -math.pi / 2 + 2 * math.pi * k / n
        o.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="#1D5E40" stroke-width="0.3"/>'
                 % (cx, cy, cx + r * math.cos(a), cy + r * math.sin(a)))
        am = a + math.pi / n
        lx, ly = cx + (r + 3.3) * math.cos(am), cy + (r + 3.3) * math.sin(am)
        o.append('<text x="%.2f" y="%.2f" font-size="%.2f" font-weight="600" text-anchor="middle" fill="#1D5E40" font-family="%s">%d</text>'
                 % (lx, ly + fs * 0.32, fs, ctx.tokens["fonts"]["family"], k + 1))
    for i in range(1, rings + 1):
        o.append('<text x="%.2f" y="%.2f" font-size="%.2f" fill="#6B6B6B" font-family="%s">%d</text>'
                 % (cx + 0.6, cy - r * i / rings + 1.9, min(1.9, r / rings * 0.6), ctx.tokens["fonts"]["family"], i))
    o.append("</svg>")
    return "".join(o)


def svg_emblem(size):
    """Знак на обложку: круг со спицами, как на тетради 2025 года."""
    c = size / 2
    r = size / 2 - 1
    o = ['<svg width="%s" height="%s" viewBox="0 0 %.2f %.2f">' % (mm(size), mm(size), size, size)]
    for i, k in enumerate((1.0, 0.8, 0.6, 0.4, 0.2)):
        o.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="none" stroke="#F1EFE6" stroke-width="%.2f" stroke-opacity="%.2f"/>'
                 % (c, c, r * k, 0.35 if i == 0 else 0.22, 1 if i == 0 else 0.7))
    for j in range(16):
        a = 2 * math.pi * j / 16
        o.append('<line x1="%.2f" y1="%.2f" x2="%.2f" y2="%.2f" stroke="#F1EFE6" stroke-width="0.22" stroke-opacity="0.8"/>'
                 % (c, c, c + r * math.cos(a), c + r * math.sin(a)))
    o.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="#F1EFE6"/>' % (c, c, r * 0.035))
    o.append('<circle cx="%.2f" cy="%.2f" r="%.2f" fill="#F1EFE6" fill-opacity="0.18"/>' % (c, c, r * 0.11))
    o.append("</svg>")
    return "".join(o)


def svg_dots(w, h, step):
    o = ['<svg width="%s" height="%s" viewBox="0 0 %.2f %.2f">' % (mm(w), mm(h), w, h)]
    y = step / 2
    while y < h:
        x = step / 2
        while x < w:
            o.append('<circle cx="%.2f" cy="%.2f" r="0.22" fill="#8C8C8C"/>' % (x, y))
            x += step
        y += step
    o.append("</svg>")
    return "".join(o)


def img_path(ctx, src):
    """Картинка ищется в папке тетради, потом в корне конструктора. Возвращает путь от корня."""
    if isinstance(src, str) and src and not Path(src).is_absolute():
        for base in (ctx.book_dir, ROOT / "brand"):
            p = (base / src).resolve()
            if p.is_relative_to(base) and p.is_file():
                return p.relative_to(ROOT).as_posix()
    ctx.err("картинка не найдена: %s (клади в папку тетради, например images/имя.png)" % src)
    return None


# ---------- блоки ----------

def line_rows(ctx, n, numbered=False, start=1):
    o = []
    for i in range(n):
        if numbered:
            o.append('<div class="ln num"><span class="ln-n">%d.</span></div>' % (start + i))
        else:
            o.append('<div class="ln"></div>')
    return "".join(o)


def B_h(ctx, b):
    if not check_keys(ctx, b, "h", ["text"], ["level", "sub"]):
        return ""
    lv = 2 if b.get("level") == 2 else 1
    sub = '<div class="h-sub">%s</div>' % esc(ctx, b["sub"]) if b.get("sub") else ""
    return '<div class="blk blk-h" id="%s"><div class="h%d">%s</div>%s</div>' % (ctx.bid(), lv, esc(ctx, b["text"]), sub)


def B_p(ctx, b):
    if not check_keys(ctx, b, "p", ["text"], ["small", "bold"]):
        return ""
    cls = "p" + (" small" if b.get("small") else "") + (" bold" if b.get("bold") else "")
    return '<p class="blk %s" id="%s">%s</p>' % (cls, ctx.bid(), esc(ctx, b["text"]))


def _list(ctx, items, ordered=False, start=1):
    tag = "ol" if ordered else "ul"
    style = ' style="--start:%d"' % (start - 1) if ordered and start != 1 else ""
    return '<%s class="%s"%s>%s</%s>' % (tag, tag, style, "".join("<li>%s</li>" % esc(ctx, x) for x in array(items, "items")), tag)


def B_rows(ctx, b):
    if not check_keys(ctx, b, "rows", ["items"]):
        return ""
    o = []
    for it in array(b["items"], "items"):
        if not check_keys(ctx, it, "rows → элемент", ["label"], ["text", "list", "ordered"]):
            continue
        r = ""
        if it.get("text"):
            r += "".join("<p>%s</p>" % esc(ctx, t) for t in str(it["text"]).split("\n\n"))
        if it.get("list"):
            r += _list(ctx, it["list"], it.get("ordered", False))
        o.append('<div class="row"><div class="row-l">%s</div><div class="row-r">%s</div></div>' % (esc(ctx, it["label"]), r))
    return '<div class="blk rows" id="%s">%s</div>' % (ctx.bid(), "".join(o))


def B_list(ctx, b):
    if not check_keys(ctx, b, "list", ["items"], ["ordered", "cols", "small"]):
        return ""
    items = array(b["items"], "list.items")
    cols = count(b.get("cols", 1), "list.cols", high=3)
    cls = "blk list" + (" small" if b.get("small") else "")
    if cols <= 1:
        return '<div class="%s" id="%s">%s</div>' % (cls, ctx.bid(), _list(ctx, items, b.get("ordered", False)))
    per = math.ceil(len(items) / cols)
    parts = []
    for c in range(cols):
        chunk = items[c * per:(c + 1) * per]
        parts.append("<div>%s</div>" % _list(ctx, chunk, b.get("ordered", False), start=c * per + 1))
    return '<div class="%s list-cols" id="%s">%s</div>' % (cls, ctx.bid(), "".join(parts))


def B_quote(ctx, b):
    if not check_keys(ctx, b, "quote", ["text"], ["by"]):
        return ""
    by = '<div class="quote-by">%s</div>' % esc(ctx, b["by"]) if b.get("by") else ""
    return ('<div class="blk quote" id="%s"><div class="quote-mark">“</div><div class="quote-t">%s</div>%s</div>'
            % (ctx.bid(), esc(ctx, b["text"]), by))


def B_note(ctx, b):
    if not check_keys(ctx, b, "note", ["text"]):
        return ""
    return '<div class="blk note" id="%s">%s<div class="note-t">%s</div></div>' % (ctx.bid(), svg_note(), esc(ctx, b["text"]))


def B_lines(ctx, b):
    if not check_keys(ctx, b, "lines", ["n"], ["numbered", "start", "label"]):
        return ""
    n = b["n"]
    label = '<div class="lines-label">%s</div>' % esc(ctx, b["label"]) if b.get("label") else ""
    if n == "fill":
        if b.get("numbered"):
            ctx.err("lines: «fill» нельзя нумеровать, задай число строк")
        if ctx.fill_used:
            ctx.err("lines: на странице может быть только один блок с n = \"fill\"")
        ctx.fill_used = True
        out = ""
        if label:
            out = '<div class="blk" id="%s" style="margin-bottom:0">%s</div>' % (ctx.bid(), label)
        return out + '<div class="blk lines fill"><div class="fill-clip"><div class="fill-rows">%s</div></div></div>' % line_rows(ctx, MAX_FILL_ROWS)
    if type(n) is not int or n < 1 or n > MAX_FILL_ROWS:
        ctx.err("lines: n должно быть числом от 1 до %d или \"fill\"" % MAX_FILL_ROWS)
        return ""
    cls = "blk lines" + (" numbered" if b.get("numbered") else "")
    return '<div class="%s" id="%s">%s%s</div>' % (cls, ctx.bid(), label, line_rows(ctx, n, b.get("numbered", False), int(b.get("start", 1))))


def B_questions(ctx, b):
    if not check_keys(ctx, b, "questions", ["items"], ["numbered", "start"]):
        return ""
    o = []
    for i, it in enumerate(array(b["items"], "questions.items")):
        if not check_keys(ctx, it, "questions → элемент", ["q"], ["lines", "hint"]):
            continue
        num = '<span class="q-n">%d.</span> ' % (i + int(b.get("start", 1))) if b.get("numbered") else ""
        hint = '<div class="q-hint">%s</div>' % esc(ctx, it["hint"]) if it.get("hint") else ""
        o.append('<div class="q"><div class="q-t">%s%s</div>%s%s</div>' % (num, esc(ctx, it["q"]), hint, line_rows(ctx, count(it.get("lines", 2), "questions.lines", low=0))))
    return '<div class="blk questions" id="%s">%s</div>' % (ctx.bid(), "".join(o))


def _fields(ctx, items):
    """Короткая подпись стоит в одной строке с линейкой. Если хотя бы одна подпись в блоке
    длинная, все подписи блока встают отдельной строкой, а линейки идут под ними во всю ширину."""
    items = array(items, "fields.items")
    good = [it for it in items if check_keys(ctx, it, "fields → элемент", ["label"], ["lines", "hint"])]
    avail = getattr(ctx, "avail_w", None) or ctx.body_w()
    limit = 0.62 * avail / (ctx.fmt["fs"] * 0.3528 * 0.5)
    long = any(len(str(it["label"])) + len(str(it.get("hint", ""))) + 1 > limit for it in good)
    o = []
    for it in good:
        hint = " <span>%s</span>" % esc(ctx, it["hint"]) if it.get("hint") else ""
        n = count(it.get("lines", 1), "fields.lines")
        if long:
            o.append('<div class="field long"><div class="field-t">%s%s</div>%s</div>' % (esc(ctx, it["label"]), hint, line_rows(ctx, n)))
        else:
            o.append('<div class="field"><div class="field-row"><div class="field-l">%s%s</div><div class="field-line"></div></div>%s</div>'
                     % (esc(ctx, it["label"]), hint, line_rows(ctx, n - 1)))
    return "".join(o)


def B_fields(ctx, b):
    if not check_keys(ctx, b, "fields", ["items"]):
        return ""
    return '<div class="blk fields" id="%s">%s</div>' % (ctx.bid(), _fields(ctx, b["items"]))


def B_table(ctx, b):
    if not check_keys(ctx, b, "table", ["cols", "rows"], ["row_mm", "head"]):
        return ""
    cols = array(b["cols"], "table.cols")
    if not cols or len(cols) > 12 or any(not 0 < float(c.get("w", 1)) < 10000 for c in cols):
        raise ValueError("table.cols: от 1 до 12 колонок, веса должны быть положительными")
    total = sum(float(c.get("w", 1)) for c in cols) or 1
    cg = "".join('<col style="width:%.2f%%">' % (float(c.get("w", 1)) / total * 100) for c in cols)
    head = ""
    if b.get("head", True):
        head = "<tr>%s</tr>" % "".join("<th>%s</th>" % esc(ctx, c.get("title", "")) for c in cols)
    rh = float(b.get("row_mm", ctx.fmt["pitch"] + 2))
    if not 0 < rh <= ctx.body_h():
        raise ValueError("table.row_mm: высота строки должна помещаться на странице")
    rows = b["rows"]
    body = []
    if type(rows) is int:
        for _ in range(count(rows, "table.rows", low=0)):
            body.append('<tr style="height:%s">%s</tr>' % (mm(rh), "<td></td>" * len(cols)))
    else:
        for r in array(rows, "table.rows"):
            r = array(r, "строка таблицы")
            if len(r) != len(cols):
                ctx.err("table: в строке %d ячеек, а колонок %d" % (len(r), len(cols)))
            body.append('<tr style="height:%s">%s</tr>' % (mm(rh), "".join("<td>%s</td>" % esc(ctx, c) for c in r)))
    return '<div class="blk" id="%s"><table class="tbl"><colgroup>%s</colgroup>%s%s</table></div>' % (ctx.bid(), cg, head, "".join(body))


def B_image(ctx, b):
    if not check_keys(ctx, b, "image", ["src", "h_mm"], ["caption", "fit", "w_mm"]):
        return ""
    p = img_path(ctx, b["src"])
    if not p:
        return ""
    h = float(b["h_mm"])
    w = float(b.get("w_mm", ctx.body_w()))
    if not (0 < w <= ctx.body_w() and 0 < h <= ctx.fmt["page-h"]):
        ctx.err("image: размеры картинки должны быть положительными и помещаться на странице")
        return ""
    fit = "cover" if b.get("fit") == "cover" else "contain"
    ctx.images.append((p, w, h, fit, ctx.where))
    cap = '<div class="image-cap">%s</div>' % esc(ctx, b["caption"]) if b.get("caption") else ""
    return ('<div class="blk image" id="%s"><img src="%s" style="height:%s;width:%s;margin:0 auto;object-fit:%s">%s</div>'
            % (ctx.bid(), quote(p), mm(h), mm(w), fit, cap))


def B_scale(ctx, b):
    if not check_keys(ctx, b, "scale", [], ["label", "from", "to", "style", "left", "right"]):
        return ""
    a, z = int(b.get("from", 1)), int(b.get("to", 10))
    if z - a + 1 > 12 or z <= a:
        ctx.err("scale: шкала должна быть от 2 до 12 делений")
        return ""
    if b.get("style") == "battery":
        cells = "".join('<div class="battery-cell">%d</div>' % v for v in range(z, a - 1, -1))
        lab = '<div class="battery-label">%s</div>' % esc(ctx, b["label"]) if b.get("label") else ""
        return ('<div class="blk scale" id="%s">%s<div class="battery"><div class="battery-cap"></div><div class="battery-body">%s</div></div></div>'
                % (ctx.bid(), lab, cells))
    lab = '<div class="scale-label">%s</div>' % esc(ctx, b["label"]) if b.get("label") else ""
    left = '<div class="scale-cap l">%s</div>' % esc(ctx, b["left"]) if b.get("left") else ""
    right = '<div class="scale-cap r">%s</div>' % esc(ctx, b["right"]) if b.get("right") else ""
    dots = "".join('<div class="dot">%d</div>' % v for v in range(a, z + 1))
    return ('<div class="blk scale" id="%s">%s<div class="scale-row">%s<div class="scale-dots">%s</div>%s</div></div>'
            % (ctx.bid(), lab, left, dots, right))


def B_checks(ctx, b):
    if not check_keys(ctx, b, "checks", ["items"], ["cols", "small"]):
        return ""
    cols = min(3, max(1, int(b.get("cols", 1))))
    items = array(b["items"], "checks.items")
    if cols > 1:  # читаем сверху вниз по колонкам, как в печатных чек-листах
        per = math.ceil(len(items) / cols)
        grid = [items[c * per:(c + 1) * per] for c in range(cols)]
        items = [grid[c][r] for r in range(per) for c in range(cols) if r < len(grid[c])]
    cls = "blk checks c%d" % cols + (" small" if b.get("small") else "")
    return '<div class="%s" id="%s">%s</div>' % (cls, ctx.bid(), "".join('<div class="check">%s</div>' % esc(ctx, x) for x in items))


def B_goal(ctx, b):
    if not check_keys(ctx, b, "goal", [], ["left", "right", "box_mm", "fields"]):
        return ""
    h = float(b.get("box_mm", 2 * ctx.fmt["pitch"]))
    caps = ('<div class="goal-caps"><div class="g-l">%s</div><div class="g-a"></div><div class="g-r">%s</div></div>'
            % (esc(ctx, b.get("left", "Сфера жизни")), esc(ctx, b.get("right", "Фокус-цель"))))
    boxes = ('<div class="goal-boxes"><div class="g-l goal-box" style="height:%s"></div><div class="g-a">%s</div><div class="g-r goal-box" style="height:%s"></div></div>'
             % (mm(h), svg_arrow(), mm(h)))
    f = '<div class="fields">%s</div>' % _fields(ctx, b["fields"]) if b.get("fields") else ""
    return '<div class="blk goal" id="%s">%s%s%s</div>' % (ctx.bid(), caps, boxes, f)


def B_wheel(ctx, b):
    if not check_keys(ctx, b, "wheel", ["labels"], ["rings", "size_mm"]):
        return ""
    labels = array(b["labels"], "wheel.labels")
    if not 3 <= len(labels) <= 12:
        ctx.err("wheel: сфер должно быть от 3 до 12")
        return ""
    size = float(b.get("size_mm", min(110, ctx.body_w() * 0.66)))
    rings = int(b.get("rings", 10))
    if not (30 <= size <= ctx.body_w() and 2 <= rings <= 12):
        ctx.err("wheel: нужно от 2 до 12 колец, размер от 30 мм до ширины страницы")
        return ""
    legend = '<div class="wheel-legend">%s</div>' % _list(ctx, labels, ordered=True)
    return '<div class="blk wheel" id="%s">%s%s</div>' % (ctx.bid(), svg_wheel(ctx, len(labels), rings, size), legend)


def B_cols(ctx, b):
    if not check_keys(ctx, b, "cols", ["cols"]):
        return ""
    parts = []
    cols = array(b["cols"], "cols.cols")
    if not 2 <= len(cols) <= 3:
        raise ValueError("cols.cols: нужно от 2 до 3 колонок")
    ctx.avail_w = (ctx.body_w() - ctx.fmt["gap"] * 1.6 * (len(cols) - 1)) / len(cols)
    for col in cols:
        inner = []
        for sub in array(col, "колонка"):
            kind = sub.get("b") if isinstance(sub, dict) else None
            if kind in ("cols",) or (kind == "lines" and sub.get("n") == "fill"):
                ctx.err("cols: внутри колонок нельзя вкладывать колонки и линейки «fill»")
                continue
            inner.append(render_block(ctx, sub))
        parts.append('<div class="col">%s</div>' % "".join(inner))
    ctx.avail_w = None
    return '<div class="blk cols" id="%s">%s</div>' % (ctx.bid(), "".join(parts))


def B_space(ctx, b):
    if not check_keys(ctx, b, "space", ["mm"]):
        return ""
    size = float(b["mm"])
    if not 0 <= size <= ctx.body_h():
        raise ValueError("space.mm: отступ должен помещаться на странице")
    return '<div style="height:%s"></div>' % mm(size)


BLOCKS = {"h": B_h, "p": B_p, "rows": B_rows, "list": B_list, "quote": B_quote, "note": B_note, "lines": B_lines,
          "questions": B_questions, "fields": B_fields, "table": B_table, "image": B_image, "scale": B_scale,
          "checks": B_checks, "goal": B_goal, "wheel": B_wheel, "cols": B_cols, "space": B_space}


def render_block(ctx, b):
    kind = b.get("b") if isinstance(b, dict) else None
    if not isinstance(kind, str) or kind not in BLOCKS:
        ctx.err("неизвестный блок «%s». Доступные: %s" % (kind, ", ".join(BLOCKS)))
        return ""
    try:
        return BLOCKS[kind](ctx, b)
    except (TypeError, ValueError, KeyError, AttributeError) as e:
        ctx.err("блок «%s» описан неверно: %s" % (kind, e))
        return ""


def render_blocks(ctx, blocks):
    return "".join(render_block(ctx, b) for b in array(blocks, "blocks"))


# ---------- страницы ----------

def band_title(ctx, title):
    """Первая фраза до точки жирная и зелёная, как в тетради 2025 года."""
    t = title or ""
    if ". " in t:
        lead, rest = t.split(". ", 1)
        return "<b>%s.</b> %s" % (esc(ctx, lead), esc(ctx, rest))
    return "<b>%s</b>" % esc(ctx, t)


def frame(ctx, pg, inner, cls="", band=True, foot=True, full=False):
    """Обычная страница: шапка с названием раздела, поле, номер."""
    ch = ctx.chapter
    show_band = band and ch.get("band", True) and pg.get("band", True)
    o = []
    if show_band:
        o.append('<div class="band"><div class="band-t fit">%s</div></div>' % band_title(ctx, pg.get("band_title") or ch.get("title", "")))
    o.append('<div class="body fit%s">%s</div>' % (" full" if (full or not show_band) else "", inner))
    if foot:
        o.append('<div class="foot fit"><span class="foot-book">%s</span><span class="foot-no">%d</span></div>'
                 % (esc(ctx, ctx.book.get("footer", ctx.book.get("title", ""))), ctx.page_no))
    return "".join(o)


def T_page(ctx, pg):
    check_keys(ctx, pg, "page", ["blocks"], ["title", "sub", "band", "band_title"])
    head = ""
    if pg.get("title"):
        head = render_block(ctx, {"b": "h", "text": pg["title"], **({"sub": pg["sub"]} if pg.get("sub") else {})})
    return frame(ctx, pg, head + render_blocks(ctx, pg.get("blocks", [])))


def T_cover(ctx, pg):
    check_keys(ctx, pg, "cover", ["title"], ["subtitle", "author", "motto", "emblem", "image", "theme"])
    f = ctx.fmt
    bg = '<div class="bg bg-%s"></div>' % ("green" if pg.get("theme") == "green" else "dark")
    if pg.get("image"):
        p = img_path(ctx, pg["image"])
        if p:
            ctx.images.append((p, f["page-w"] + 2 * ctx.bleed, f["page-h"] + 2 * ctx.bleed, "cover", ctx.where))
            bg = '<div class="bg"><img src="%s"></div><div class="cover-shade"></div>' % quote(p)
    emb = pg.get("emblem", "wheel")
    size = f["page-w"] * 0.46
    e = ""
    if emb == "wheel":
        e = svg_emblem(size)
    elif emb == "mark":
        e = '<img src="brand/mark-cream.png" style="width:%s;height:%s">' % (mm(size * 0.5), mm(size * 0.5))
    if len(pg.get("title", "")) > 28:
        ctx.warn("cover: название длиннее 28 знаков, проверь обложку глазами")
    o = [bg, '<div class="cover fit">', '<div class="cover-emblem">%s</div>' % e,
         '<div class="cover-title" id="%s">%s</div>' % (ctx.bid(), esc(ctx, pg["title"]))]
    if pg.get("subtitle"):
        o.append('<div class="cover-sub">%s</div>' % esc(ctx, pg["subtitle"]))
    if pg.get("author"):
        o.append('<div class="cover-author">%s</div>' % esc(ctx, pg["author"]))
    if pg.get("motto"):
        o.append('<div class="cover-motto">%s</div>' % esc(ctx, pg["motto"]))
    o.append("</div>")
    return "".join(o)


def T_back(ctx, pg):
    check_keys(ctx, pg, "back", [], ["text", "contacts", "theme"])
    bg = '<div class="bg bg-%s"></div>' % ("green" if pg.get("theme") == "green" else "dark")
    c = "".join("<div>%s</div>" % esc(ctx, x) for x in array(pg.get("contacts", []), "back.contacts"))
    t = '<div class="back-t">%s</div>' % esc(ctx, pg["text"]) if pg.get("text") else ""
    return '%s<div class="back fit" id="%s"><img src="brand/mark-cream.png">%s<div class="back-c">%s</div></div>' % (bg, ctx.bid(), t, c)


def T_opener(ctx, pg):
    check_keys(ctx, pg, "opener", ["title"], ["kicker", "lead", "points", "points_title"])
    o = ['<div class="bg bg-green"></div><div class="opener fit">']
    if pg.get("kicker"):
        o.append('<div class="opener-k">%s</div>' % esc(ctx, pg["kicker"]))
    o.append('<div class="opener-t" id="%s">%s</div>' % (ctx.bid(), esc(ctx, pg["title"])))
    if pg.get("lead"):
        o.append('<div class="opener-lead" id="%s">%s</div>' % (ctx.bid(), esc(ctx, pg["lead"])))
    if pg.get("points"):
        o.append('<div id="%s"><div class="opener-ph">%s</div>%s</div>' % (
            ctx.bid(), esc(ctx, pg.get("points_title", "На встрече")),
            "".join('<div class="opener-p">%s</div>' % esc(ctx, x) for x in array(pg["points"], "opener.points"))))
    o.append("</div>")
    o.append('<img class="opener-mark" src="brand/mark-cream.png"><div class="opener-no">%d</div>' % ctx.page_no)
    return "".join(o)


def T_owner(ctx, pg):
    check_keys(ctx, pg, "owner", [], ["title", "fields", "text"])
    fields = pg.get("fields", ["Имя", "Поток", "Дата начала", "Телефон, если тетрадь потеряется"])
    inner = ['<div class="owner-t" id="%s">%s</div>' % (ctx.bid(), esc(ctx, pg.get("title", "Эта тетрадь принадлежит")))]
    inner.append('<div class="blk fields" id="%s">%s</div>' % (ctx.bid(), _fields(ctx, [{"label": x} for x in array(fields, "owner.fields")])))
    if pg.get("text"):
        inner.append('<p class="owner-text" id="%s">%s</p>' % (ctx.bid(), esc(ctx, pg["text"])))
    inner.append('<img class="owner-mark" src="brand/mark-green.png">')
    return frame(ctx, pg, "".join(inner), band=False, foot=False, full=True)


def T_contents(ctx, pg):
    check_keys(ctx, pg, "contents", [], ["title"])
    rows = "".join('<div class="toc-row"><div class="toc-n">%02d</div><div class="toc-t">%s</div><div class="toc-p">%d</div></div>'
                   % (i + 1, esc(ctx, t), p) for i, (t, p) in enumerate(ctx.toc))
    head = render_block(ctx, {"b": "h", "text": pg.get("title", "Содержание")})
    return frame(ctx, pg, head + '<div id="%s">%s</div>' % (ctx.bid(), rows), band=False, full=True)


def T_author(ctx, pg):
    check_keys(ctx, pg, "author", ["name"], ["photo", "role", "blocks"])
    ph = ""
    if pg.get("photo"):
        p = img_path(ctx, pg["photo"])
        if p:
            ctx.images.append((p, 62, 76, "cover", ctx.where))
            ph = '<img src="%s">' % quote(p)
    role = '<div class="author-role">%s</div>' % esc(ctx, pg["role"]) if pg.get("role") else ""
    o = ['<div class="author-top" id="%s"><div class="author-ph">%s</div><div class="author-id"><div class="author-name">%s</div>%s</div></div>'
         % (ctx.bid(), ph, esc(ctx, pg["name"]), role)]
    for blk in array(pg.get("blocks", []), "author.blocks"):
        o.append('<div id="%s"><div class="author-h">%s</div><div class="list small">%s</div></div>'
                 % (ctx.bid(), esc(ctx, blk.get("h", "")), _list(ctx, blk.get("items", []))))
    return frame(ctx, pg, "".join(o), band=False, full=True)


def T_tracker(ctx, pg):
    check_keys(ctx, pg, "tracker", [], ["title", "sub", "text", "rows", "days", "name_title", "band", "band_title"])
    days = count(pg.get("days", 31), "tracker.days", high=31)
    rows = pg.get("rows", 10)
    names = rows if isinstance(rows, list) else [""] * count(rows, "tracker.rows")
    head = "<tr><th class=\"trk-name\">%s</th>%s</tr>" % (esc(ctx, pg.get("name_title", "Привычка")),
                                                         "".join("<th>%d</th>" % d for d in range(1, days + 1)))
    body = "".join('<tr><td class="trk-name">%s</td>%s</tr>' % (esc(ctx, n), "<td></td>" * days) for n in names)
    o = []
    if pg.get("title"):
        o.append(render_block(ctx, {"b": "h", "text": pg["title"], **({"sub": pg["sub"]} if pg.get("sub") else {})}))
    if pg.get("text"):
        o.append(render_block(ctx, {"b": "p", "text": pg["text"]}))
    o.append('<div class="blk" id="%s"><table class="trk">%s%s</table></div>' % (ctx.bid(), head, body))
    return frame(ctx, pg, "".join(o))


def T_track(ctx, pg):
    check_keys(ctx, pg, "track", ["periods"], ["title", "sub", "text", "band", "band_title"])
    o = []
    if pg.get("title"):
        o.append(render_block(ctx, {"b": "h", "text": pg["title"], **({"sub": pg["sub"]} if pg.get("sub") else {})}))
    if pg.get("text"):
        o.append(render_block(ctx, {"b": "p", "text": pg["text"]}))
    for p in array(pg["periods"], "track.periods"):
        o.append('<div class="track-p" id="%s"><div class="track-tag">%s</div><div class="track-f">%s</div></div>'
                 % (ctx.bid(), esc(ctx, p.get("label", "")), _fields(ctx, p.get("fields", []))))
    return frame(ctx, pg, "".join(o))


def T_summary(ctx, pg):
    check_keys(ctx, pg, "summary", ["items"], ["title", "sub", "band", "band_title"])
    o = [render_block(ctx, {"b": "h", "text": pg.get("title", "Итог встречи"), **({"sub": pg["sub"]} if pg.get("sub") else {})})]
    for it in array(pg["items"], "summary.items"):
        o.append('<div class="sum-box" id="%s"><div class="sum-l">%s</div>%s</div>'
                 % (ctx.bid(), esc(ctx, it.get("label", "")), line_rows(ctx, count(it.get("lines", 3), "summary.lines"))))
    return frame(ctx, pg, "".join(o))


def T_notes(ctx, pg):
    check_keys(ctx, pg, "notes", [], ["title", "style", "band", "band_title"])
    head = render_block(ctx, {"b": "h", "text": pg.get("title", "Заметки")})
    if pg.get("style") == "dots":
        h = ctx.body_h() - ctx.fmt["lh-h1"] - ctx.fmt["gap"]
        return frame(ctx, pg, head + '<div class="dots">%s</div>' % svg_dots(ctx.body_w(), h, 5))
    ctx.fill_used = True
    return frame(ctx, pg, head + '<div class="blk lines fill"><div class="fill-clip"><div class="fill-rows">%s</div></div></div>' % line_rows(ctx, MAX_FILL_ROWS))


def T_image(ctx, pg):
    check_keys(ctx, pg, "image", ["src"], ["caption"])
    p = img_path(ctx, pg["src"])
    if not p:
        return ""
    f = ctx.fmt
    ctx.images.append((p, f["page-w"] + 2 * ctx.bleed, f["page-h"] + 2 * ctx.bleed, "cover", ctx.where))
    cap = '<div class="pic-cap fit">%s</div>' % esc(ctx, pg["caption"]) if pg.get("caption") else ""
    return '<div class="pic" id="%s"><img src="%s"></div>%s' % (ctx.bid(), quote(p), cap)


PAGES = {"page": T_page, "cover": T_cover, "back": T_back, "opener": T_opener, "owner": T_owner, "contents": T_contents,
         "author": T_author, "tracker": T_tracker, "track": T_track, "summary": T_summary, "notes": T_notes, "image": T_image}
COVER_KINDS = ("cover", "back")


# ---------- сборка HTML ----------

def css_vars(tokens, fmt_name, bleed):
    f = tokens["formats"][fmt_name]
    v = {}
    for k, val in tokens["colors"].items():
        v[k] = val
    for k, val in f.items():
        v[k] = ("%spt" % val) if k.startswith("fs") else mm(val)
    v["font"] = '"%s"' % tokens["fonts"]["family"]
    v["bleed-neg"] = mm(-bleed)
    v["band-full"] = mm(f["band-h"] + bleed)
    v["band-pad"] = mm(f["band-h"] * 0.22)
    v["x-inner-b"] = mm(f["m-inner"] + bleed)
    v["x-outer-b"] = mm(f["m-outer"] + bleed)
    v["gap-half"] = mm(f["gap"] / 2)
    v["dot"] = mm(f["pitch"] * 0.82)
    v["dot-lh"] = mm(f["pitch"] * 0.82 - 0.6)
    v["dot-top"] = mm((f["lh"] - 1.5) / 2)
    v["box-top"] = mm((f["lh"] - 3.6) / 2)
    v["toc-h"] = mm(f["pitch"] * 1.6)
    v["trk-name"] = mm(f["label-w"] * 1.1)
    v["col-gap"] = mm(f["gap"] * 1.6)
    v["number-rule"] = mm(f["pitch"] * 0.9)
    v["fill-top"] = mm(f["pitch"] * 0.75)
    v["fs-quote"] = "%spt" % round(f["fs"] * 4, 1)
    return ":root{%s}" % "".join("--%s:%s;" % (k, val) for k, val in v.items())


def font_faces(tokens):
    fam = tokens["fonts"]["family"]
    return "".join('@font-face{font-family:"%s";font-weight:%s;font-style:normal;src:url("%s") format("truetype")}' % (fam, w, p)
                   for w, p in tokens["fonts"]["files"].items())


def load_book(book_dir):
    bj = book_dir / "book.json"
    if not bj.is_file():
        raise Problem("нет файла %s" % bj)
    try:
        book = json.loads(bj.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise Problem("book.json не читается: строка %d, %s" % (e.lineno, e.msg))
    if not isinstance(book, dict):
        raise Problem("book.json должен содержать объект")
    book.setdefault("format", "A4")
    if not isinstance(book.get("title"), str) or not book["title"].strip():
        raise Problem("в book.json нужен непустой title")
    chapters = []
    for p in sorted((book_dir / "chapters").glob("*.json")):
        try:
            ch = json.loads(p.read_text(encoding="utf-8"))
        except json.JSONDecodeError as e:
            raise Problem("chapters/%s не читается: строка %d, %s" % (p.name, e.lineno, e.msg))
        if not isinstance(ch, dict) or not isinstance(ch.get("pages"), list):
            raise Problem(f"chapters/{p.name}: нужен объект со списком pages")
        if "title" in ch and not isinstance(ch["title"], str):
            raise Problem(f"chapters/{p.name}: title должен быть текстом")
        ch["_file"] = p.name
        chapters.append(ch)
    if not chapters:
        raise Problem("в папке chapters нет ни одного файла .json")
    return book, chapters


def build_html(book_dir, tokens, print_mode=False):
    """Возвращает (html, ctx). Один элемент pages в JSON = ровно одна страница тетради."""
    book, chapters = load_book(book_dir)
    if book["format"] not in tokens["formats"]:
        raise Problem("формат «%s» не описан в design/tokens.json" % book["format"])
    if "footer" in book and not isinstance(book["footer"], str):
        raise Problem("в book.json поле footer должно быть текстом")
    ctx = Ctx(book, book_dir, tokens)
    ctx.bleed = float(tokens["print"]["bleed"]) if print_mode else 0
    # первый проход: номера страниц для содержания
    n = 0
    k = 0
    for ch in chapters:
        pages = ch.get("pages", [])
        if ch.get("toc", True) and pages:
            k += 1
            ctx.toc.append((ch.get("toc_title") or ch.get("title", "Раздел %d" % k), n + 1))
        n += len(pages)
    total = n
    if not total:
        raise Problem("в описании тетради нет страниц")
    out = []
    n = 0
    kinds = []
    for ch in chapters:
        ctx.chapter = ch
        for i, pg in enumerate(ch.get("pages", [])):
            n += 1
            ctx.page_no = n
            ctx.side = "recto" if n % 2 else "verso"
            ctx.where = "chapters/%s, страница %d (в тетради стр. %d)" % (ch["_file"], i + 1, n)
            ctx.block_ids = []
            ctx._bn = 0
            ctx.fill_used = False
            ctx.avail_w = None
            kind = pg.get("t", "page") if isinstance(pg, dict) else None
            kinds.append(kind)
            if not isinstance(kind, str) or kind not in PAGES:
                ctx.err("неизвестный вид страницы «%s». Доступные: %s" % (kind, ", ".join(PAGES)))
                inner = ""
            else:
                try:
                    inner = PAGES[kind](ctx, pg)
                except (TypeError, ValueError, KeyError, AttributeError) as e:
                    ctx.err("страница «%s» описана неверно: %s" % (kind, e))
                    inner = ""
            ctx.pages_ids[n] = list(ctx.block_ids)
            ctx.page_where[n] = ctx.where
            out.append('<section class="pg %s t-%s" id="p-%03d">%s</section>' % (ctx.side, kind if isinstance(kind, str) and kind in PAGES else "invalid", n, inner))
    ctx.total = total
    ctx.kinds = kinds
    f = ctx.fmt
    bleed = ctx.bleed
    page_rule = "@page{size:%s %s;margin:0;%s}" % (mm(f["page-w"]), mm(f["page-h"]),
                                                  "bleed:%s;" % mm(bleed) if print_mode else "")
    css = (ROOT / "engine" / "css" / "base.css").read_text(encoding="utf-8")
    doc = ('<!doctype html><html lang="ru"><head><meta charset="utf-8"><title>%s</title><style>%s%s%s%s</style></head><body>%s</body></html>'
           % (html.escape(book.get("title", "Тетрадь")), font_faces(tokens), page_rule, css_vars(tokens, book["format"], bleed), css, "".join(out)))
    return doc, ctx
