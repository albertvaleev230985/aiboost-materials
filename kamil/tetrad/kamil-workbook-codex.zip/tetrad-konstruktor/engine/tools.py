"""Вспомогательные команды конструктора.

scan   разложить готовый PDF (например, тетрадь прошлого года) на картинки страниц,
       чтобы агент мог прочитать его глазами и составить карту упражнений;
skill  записать навык в общую папку навыков, чтобы тетрадь вызывалась из любого чата.
"""
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw

from .render import ROOT

PER_SHEET = 12
SKILL_NAME = "workbook-kamil"
SKILL_TEXT = """---
name: workbook-kamil
description: Печатные рабочие тетради Камиля Амирханова. Используй, когда просят сделать, поправить, сверстать или собрать тетрадь, воркбук, страницу, разворот, чек-лист или трекер к курсу, а также перенести старую тетрадь в новый вид.
---

# Тетради Камиля

Конструктор тетрадей лежит в папке `{root}`.

1. Перейди в эту папку. Все команды запускай из неё.
2. Прочитай там `AGENTS.md`, затем `.agents/skills/workbook-kamil/SKILL.md`. Это правила и порядок работы.
3. Тетрадь описывается файлами в `books/<имя>/`, собирается командой `./workbook <имя>`. Движок в `engine/` и стили не правь.
4. Работу считай сделанной только после сборки без ошибок и просмотра листов `out/<имя>/preview/sheet-*.jpg`.

Если папки по этому адресу нет, скажи об этом пользователю и спроси, куда она переехала.
"""


class ToolError(Exception):
    pass


def run(*args):
    try:
        return subprocess.run(args, check=True, capture_output=True, text=True).stdout
    except FileNotFoundError as exc:
        raise ToolError("Не найдена утилита %s. Запусти ./workbook --setup." % args[0]) from exc
    except subprocess.CalledProcessError as exc:
        raise ToolError("%s: %s" % (args[0], exc.stderr.strip() or exc.returncode)) from exc


def scan(pdf, name, books=None, resolution=110):
    """PDF → books/<имя>/source/p-001.jpg … плюс листы миниатюр и index.json."""
    pdf = Path(pdf).expanduser()
    if not re.fullmatch(r"[\w-]+", name or ""):
        raise ToolError("Имя тетради: буквы, цифры, дефис или подчёркивание, без пробелов.")
    if not pdf.is_file():
        raise ToolError("Файл не найден: %s" % pdf)
    info = run("pdfinfo", str(pdf))
    found = re.search(r"^Pages:\s+(\d+)", info, re.MULTILINE)
    if not found:
        raise ToolError("Не удалось прочитать число страниц. Это точно PDF?")
    pages = int(found.group(1))
    size = re.search(r"^Page size:\s+([\d.]+) x ([\d.]+) pts", info, re.MULTILINE)
    size_mm = [round(float(v) / 72 * 25.4) for v in size.groups()] if size else None
    text = run("pdftotext", "-l", str(min(pages, 8)), str(pdf), "-")
    has_text = len(re.sub(r"\s", "", text)) > 40 * min(pages, 8)

    dest = (books or ROOT / "books") / name / "source"
    dest.mkdir(parents=True, exist_ok=True)
    for old in list(dest.glob("p-*.jpg")) + list(dest.glob("sheet-*.jpg")):
        old.unlink()
    with tempfile.TemporaryDirectory(dir=dest) as scratch:
        run("pdftoppm", "-r", str(resolution), "-jpeg", "-jpegopt", "quality=82", str(pdf), str(Path(scratch) / "p"))
        files = sorted(Path(scratch).glob("p-*.jpg"), key=lambda p: int(p.stem.split("-")[-1]))
        if len(files) != pages:
            raise ToolError("Растеризовано %d из %d страниц." % (len(files), pages))
        for i, f in enumerate(files, start=1):
            shutil.move(str(f), dest / ("p-%03d.jpg" % i))

    files = [dest / ("p-%03d.jpg" % i) for i in range(1, pages + 1)]
    tile_w, tile_h, margin = 300, 440, 16
    for start in range(0, pages, PER_SHEET):
        batch = files[start:start + PER_SHEET]
        rows = (len(batch) + 3) // 4
        sheet = Image.new("RGB", (4 * tile_w + margin, rows * tile_h + margin), "#E8E6DE")
        draw = ImageDraw.Draw(sheet)
        for k, path in enumerate(batch):
            x = margin + (k % 4) * tile_w
            y = margin + (k // 4) * tile_h
            with Image.open(path) as page:
                page.thumbnail((tile_w - margin, tile_h - 34), Image.Resampling.LANCZOS)
                sheet.paste(page, (x, y))
                draw.rectangle((x - 1, y - 1, x + page.width, y + page.height), outline="#B5B6AE")
            draw.text((x, y + tile_h - 30), "стр. %d" % (start + k + 1), fill="#1C3528")
        sheet.save(dest / ("sheet-%02d.jpg" % (start // PER_SHEET + 1)), quality=88)

    index = {"pdf": pdf.name, "pages": pages, "page_mm": size_mm, "has_text": has_text}
    (dest / "index.json").write_text(json.dumps(index, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return dest, index


def install_skill(target=None):
    """Кладёт навык в общую папку навыков Codex и вписывает в него путь к конструктору."""
    if target:
        base = Path(target).expanduser()
    else:
        home = Path.home()
        base = next((p for p in (home / ".codex" / "skills", home / ".agents" / "skills") if p.is_dir()),
                    home / ".codex" / "skills")
    folder = base / SKILL_NAME
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / "SKILL.md"
    path.write_text(SKILL_TEXT.format(root=ROOT), encoding="utf-8")
    return path


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    try:
        if argv[:1] == ["scan"] and len(argv) == 3:
            dest, index = scan(argv[1], argv[2])
            print("Страниц: %d, формат %s мм. Картинки страниц и листы миниатюр: %s"
                  % (index["pages"], " x ".join(map(str, index["page_mm"] or ["?"])), dest))
            if index["has_text"]:
                print("В PDF есть текстовый слой. Формулировки всё равно сверяй по картинкам страниц.")
            else:
                print("Текстового слоя в PDF нет (свёрстан в кривых). Читай страницы как картинки: p-001.jpg и далее.")
            return 0
        if argv[:1] == ["skill"] and len(argv) <= 2:
            path = install_skill(argv[1] if len(argv) == 2 else None)
            print("Навык записан: %s. Перезапусти Codex, чтобы он появился в списке навыков." % path)
            return 0
    except (ToolError, OSError) as exc:
        print("Не получилось.\n%s" % exc, file=sys.stderr)
        return 1
    print("Команды: ./workbook --scan ФАЙЛ.pdf ИМЯ   или   ./workbook --install-skill [ПАПКА]", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
