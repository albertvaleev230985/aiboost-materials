"""Compile a workbook and run layout and PDF checks before publishing the result."""

import argparse
import fcntl
import hashlib
import json
import logging
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

from fontTools.ttLib import TTFont
from PIL import Image, ImageDraw, ImageOps
from pydyf import Array, Stream
from weasyprint import HTML, URLFetcher, __version__ as WEASYPRINT_VERSION
from weasyprint.text.fonts import FontConfiguration
from weasyprint.formatting_structure.boxes import TextBox

from .render import ROOT, Problem, build_html

ENGINE_VERSION = "70.0"
PDF_TOOLS = ("pdfinfo", "pdffonts", "pdftoppm")
PX_PER_MM = 96 / 25.4
PT_PER_MM = 72 / 25.4
MARK_MARGIN_MM = 4
TOLERANCE = 0.7 * PX_PER_MM
PER_SHEET = 12


class BuildError(Exception):
    pass


@dataclass
class BuildResult:
    pages: int
    warnings: list[str]


class RenderLog(logging.Handler):
    def __init__(self):
        super().__init__(level=logging.WARNING)
        self.errors = []
        self.warnings = []

    def emit(self, record):
        messages = self.errors if record.levelno >= logging.ERROR else self.warnings
        messages.append(record.getMessage())


def read_tokens():
    try:
        return json.loads((ROOT / "design" / "tokens.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        raise BuildError(f"Не читается design/tokens.json: {exc}") from exc


def display(messages):
    return [f"{where}: {message}" for where, message in messages]


def command(*args):
    try:
        return subprocess.run(args, check=True, capture_output=True, text=True).stdout
    except subprocess.CalledProcessError as exc:
        raise BuildError(f"{args[0]}: {exc.stderr.strip() or exc.returncode}") from exc


def validate_assets(ctx, tokens):
    glyphs = None
    for name in tokens["fonts"]["files"].values():
        path = ROOT / name
        try:
            with TTFont(path) as font:
                chars = set(font.getBestCmap())
            glyphs = chars if glyphs is None else glyphs & chars
        except (OSError, ValueError, KeyError) as exc:
            raise BuildError(f"Не читается шрифт {name}: {exc}") from exc
    for char in sorted(ctx.chars):
        if not char.isspace() and ord(char) not in glyphs:
            pages = ", ".join(str(n) for n in sorted(ctx.chars[char]))
            ctx.errors.append((f"стр. {pages}", f"нет символа {char!r} (U+{ord(char):04X}) в шрифте тетради"))

    for path, width, height, fit, where in ctx.images:
        try:
            with Image.open(ROOT / path) as source:
                w, h = ImageOps.exif_transpose(source).size
        except (OSError, ValueError) as exc:
            ctx.errors.append((where, f"картинка {path} не читается: {exc}"))
            continue
        ppi = (max if fit == "contain" else min)(w * 25.4 / width, h * 25.4 / height)
        if ppi < 240:
            ctx.warnings.append((where, f"{path}: около {ppi:.0f} ppi при этом размере, проверь требования к печати"))


def bounds(box):
    x, y = box.border_box_x(), box.border_box_y()
    return x, y, x + box.border_width(), y + box.border_height()


def walk(box):
    yield box
    for child in getattr(box, "children", ()):
        yield from walk(child)


def outside(box, area):
    left, top, right, bottom = bounds(box)
    x, y, x2, y2 = area
    # Line boxes carry vertical layout. Font metrics can extend past a line
    # box even when the line fits, while horizontal text width still matters.
    vertical = 0 if isinstance(box, TextBox) else max(y - top, bottom - y2)
    delta = max(x - left, right - x2, vertical)
    return delta if delta > TOLERANCE else 0


def first_overflow(box, area):
    # Rows and dots fill their container by design. Measure the container itself.
    for child in getattr(box, "children", ()):
        delta = outside(child, area)
        if delta:
            element = child.element
            name = (element.get("id") or element.get("class")) if element is not None else child.element_tag
            return delta, name or "текст"
        classes = child.element.get("class", "").split() if child.element is not None else ()
        if "fill" not in classes and "dots" not in classes:
            nested = first_overflow(child, area)
            if nested:
                return nested
    return None


def overlap(first, second):
    x1, y1, x2, y2 = bounds(first)
    a1, b1, a2, b2 = bounds(second)
    return max(0, min(x2, a2) - max(x1, a1)), max(0, min(y2, b2) - max(y1, b1))


def fit_area(box, classes, page, fmt):
    x, y, x2, y2 = bounds(box)
    safe_top = fmt["body-top"] * PX_PER_MM
    if "band-t" in classes:
        return x, 2 * PX_PER_MM, x2, safe_top
    if "foot" in classes:
        return x, page.height - fmt["body-bottom"] * PX_PER_MM, x2, y2
    if "back" in classes:
        return x, y, x2, page.height - fmt["body-bottom"] * PX_PER_MM
    if "pic-cap" in classes:
        margin = fmt["m-outer"] * PX_PER_MM
        return margin, page.height * 0.64, page.width - margin, page.height - margin / 4
    return x, y, x2, y2


def fitted_boxes(page, fmt):
    for box in walk(page._page_box):
        if box.element is None:
            continue
        classes = box.element.get("class", "").split()
        if "fit" not in classes or not hasattr(box, "_box"):
            continue
        area = fit_area(box, classes, page, fmt)
        if "band-t" in classes or "pic-cap" in classes:
            delta = outside(box, area)
            if delta:
                yield delta, classes[0]
                continue
        result = first_overflow(box, area)
        if result:
            yield result
        if "cover" in classes or "foot" in classes:
            parts = [child for child in box.children if child.border_height() > 0]
            for index, first in enumerate(parts):
                for second in parts[index + 1:]:
                    dx, dy = overlap(first, second)
                    if dx > TOLERANCE and dy > TOLERANCE:
                        yield dy, second.element.get("class", "текст")

        if "body" in classes:
            # The sign is intentionally anchored to the bottom. Flow must clear it.
            mark = next((child for child in box.children
                         if child.element is not None and child.element.get("class") == "owner-mark"), None)
            if mark is not None:
                for child in box.children:
                    if child is mark:
                        continue
                    dx, dy = overlap(child, mark)
                    if dx > TOLERANCE and dy > TOLERANCE:
                        yield dy, "знак внизу страницы"


def validate_layout(document, ctx):
    if len(document.pages) != ctx.total:
        return [f"В исходнике {ctx.total} стр., в вёрстке {len(document.pages)} стр. Проверь размеры страниц."]

    issues = []
    for index, page in enumerate(document.pages, start=1):
        anchor = f"p-{index:03d}"
        where = ctx.page_where[index]
        if anchor not in page.anchors:
            issues.append(f"{where}: страница сдвинулась в PDF")
            continue
        result = next(fitted_boxes(page, ctx.fmt), None)
        if result:
            amount, name = result
            issues.append(f"{where}: переполнение ({name}, {amount / PX_PER_MM:.1f} мм).")
    return issues


def add_crop_marks(_document, pdf):
    """Draw marks outside the bleed so even a dark full-bleed page has marks."""
    margin = MARK_MARGIN_MM * PT_PER_MM
    inset = 0.5 * PT_PER_MM
    for number in pdf.pages["Kids"][::3]:
        page = pdf.objects[number]
        x1, y1, x2, y2 = page["TrimBox"]
        left, bottom, right, top = page["BleedBox"]
        page["MediaBox"] = Array([left - margin, bottom - margin, right + margin, top + margin])
        marks = Stream(compress=True)
        marks.set_color_rgb(0, 0, 0, stroke=True)
        marks.set_line_width(0.4)
        for x, outer, inner in ((x1, left - margin + inset, left - inset),
                                (x2, right + margin - inset, right + inset)):
            for y in (y1, y2):
                marks.move_to(outer, y)
                marks.line_to(inner, y)
        for y, outer, inner in ((y1, bottom - margin + inset, bottom - inset),
                                (y2, top + margin - inset, top + inset)):
            for x in (x1, x2):
                marks.move_to(x, outer)
                marks.line_to(x, inner)
        marks.stroke()
        pdf.add_object(marks)
        page["Contents"] = Array([page["Contents"], marks.reference])


def validate_pdf(pdf, ctx, print_mode, marks):
    pdf_path = str(pdf)
    info = command("pdfinfo", "-f", "1", "-l", str(ctx.total), "-box", pdf_path)
    if not re.search(rf"^Pages:\s+{ctx.total}\s*$", info, re.MULTILINE):
        raise BuildError("Число страниц PDF не совпало с описанием.")
    for name in ("TrimBox", "BleedBox", "MediaBox"):
        rectangles = re.findall(rf"{name}:\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)", info)
        bleed = ctx.tokens["print"]["bleed"] if print_mode and name != "TrimBox" else 0
        margin = MARK_MARGIN_MM if marks and name == "MediaBox" else 0
        expected = [(ctx.fmt[key] + 2 * (bleed + margin)) * PT_PER_MM for key in ("page-w", "page-h")]
        if len(rectangles) != ctx.total:
            raise BuildError(f"В PDF отсутствуют области {name} для всех страниц.")
        for index, coordinates in enumerate(rectangles, start=1):
            left, top, right, bottom = map(float, coordinates)
            if abs(right - left - expected[0]) > 0.15 or abs(bottom - top - expected[1]) > 0.15:
                raise BuildError(f"PDF, стр. {index}: неверный размер {name}.")

    fonts = command("pdffonts", pdf_path).splitlines()[2:]
    if ctx.chars and not fonts:
        raise BuildError("В PDF не найден шрифт для текста.")
    names = []
    for font in fonts:
        columns = font.split()
        name = columns[0].split("+")[-1]
        if columns[-5] != "yes":
            raise BuildError(f"В PDF не встроен шрифт {name}.")
        if not name.lower().startswith(ctx.tokens["fonts"]["family"].lower().split()[0]):
            raise BuildError(f"В PDF появился незапланированный шрифт {name}.")
        names.append(name)
    return sorted(set(names))


def make_sheets(pdf, directory, total, previous):
    hashes = []
    changed = []
    with tempfile.TemporaryDirectory(dir=directory) as scratch:
        rasters = Path(scratch)
        command("pdftoppm", "-r", "65", "-png", str(pdf), str(rasters / "p"))
        files = sorted(rasters.glob("p-*.png"), key=lambda path: int(path.stem.split("-")[-1]))
        if len(files) != total:
            raise BuildError(f"Растеризовано {len(files)} из {total} страниц.")

        for start in range(0, total, PER_SHEET):
            batch = files[start:start + PER_SHEET]
            tile_w, tile_h, margin = 242, 325, 18
            rows = (len(batch) + 3) // 4
            sheet = Image.new("RGB", (4 * tile_w + margin, rows * tile_h + margin), "#E8E6DE")
            draw = ImageDraw.Draw(sheet)
            for offset, path in enumerate(batch):
                index = start + offset
                digest = hashlib.sha256(path.read_bytes()).hexdigest()
                hashes.append(digest)
                differs = previous is not None and (index >= len(previous) or previous[index] != digest)
                if differs:
                    changed.append(index + 1)
                x = margin + (offset % 4) * tile_w
                y = margin + (offset // 4) * tile_h
                with Image.open(path) as page:
                    page.thumbnail((tile_w - 30, tile_h - 33), Image.Resampling.LANCZOS)
                    px = x + (tile_w - 30 - page.width) // 2
                    sheet.paste(page, (px, y))
                    draw.rectangle((px - 1, y - 1, px + page.width, y + page.height),
                                   outline="#9F5A31" if differs else "#B5B6AE", width=2 if differs else 1)
                draw.text((x, y + tile_h - 26), str(index + 1), fill="#1C3528")
            sheet.save(directory / f"sheet-{start // PER_SHEET + 1:02d}.jpg", quality=91)
    return hashes, changed


def validate_output_dir(directory):
    if directory.is_symlink() or not directory.is_dir() or not (directory / "preflight.json").is_file():
        raise BuildError(f"Папка не похожа на результат сборки: {directory}")
    for path in directory.iterdir():
        known = path.name in ("book.pdf", "preflight.json") or re.fullmatch(r"sheet-\d+\.jpg", path.name)
        if not known or path.is_symlink() or not path.is_file():
            raise BuildError(f"Файл {path.name} не относится к сборке. Перенеси его из {directory}.")


def publish(staged, output):
    lock_path = output.with_name(f".{output.name}.lock")
    backup = output.with_name(f".{output.name}.previous")
    with lock_path.open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if backup.exists() or backup.is_symlink():
            if output.exists():
                validate_output_dir(backup)
                validate_output_dir(output)
                backup.rename(staged.parent / "obsolete")
            else:
                backup.rename(output)
        if output.exists() or output.is_symlink():
            validate_output_dir(output)
            output.rename(backup)
        try:
            staged.rename(output)
        except OSError:
            if backup.exists():
                backup.rename(output)
            raise
        if backup.exists():
            backup.rename(staged.parent / "previous")


def build(book, output, tokens, *, print_mode=False, marks=False, compare=None):
    if WEASYPRINT_VERSION != ENGINE_VERSION:
        raise BuildError(f"Нужна WeasyPrint {ENGINE_VERSION}, сейчас {WEASYPRINT_VERSION}.")
    missing = [name for name in PDF_TOOLS if not shutil.which(name)]
    if missing:
        raise BuildError(f"Не найдены утилиты Poppler: {', '.join(missing)}.")
    bleed = tokens["print"]["bleed"]
    if print_mode and (type(bleed) not in (int, float) or not 0 <= bleed <= 3 or (marks and not bleed)):
        raise BuildError("Допустимый вылет 0–3 мм. Для меток реза нужен положительный вылет.")
    if marks and not print_mode:
        raise BuildError("Для меток реза нужна печатная сборка.")
    if not book.resolve().is_relative_to(ROOT):
        raise BuildError("Исходник должен находиться в папке конструктора.")
    if output.resolve().is_relative_to(book.resolve()) or book.resolve().is_relative_to(output.resolve()):
        raise BuildError("Папка сборки должна быть отдельно от исходника.")
    try:
        html, ctx = build_html(book.resolve(), tokens, print_mode=print_mode)
    except (Problem, OSError, ValueError, TypeError, KeyError) as exc:
        raise BuildError(str(exc)) from exc

    validate_assets(ctx, tokens)
    if ctx.errors:
        raise BuildError("\n".join(display(ctx.errors)))

    handler = RenderLog()
    logger = logging.getLogger("weasyprint")
    logger.addHandler(handler)
    try:
        document = HTML(string=html, base_url=ROOT.as_uri() + "/",
                        url_fetcher=URLFetcher(allowed_protocols=("file",))).render(font_config=FontConfiguration())
    finally:
        logger.removeHandler(handler)
    issues = handler.errors + validate_layout(document, ctx)
    if issues:
        raise BuildError("\n".join(issues))

    previous = None
    if compare:
        try:
            previous = json.loads(compare.read_text(encoding="utf-8"))["page_sha256"]
            if not isinstance(previous, list) or not all(isinstance(value, str) for value in previous):
                raise ValueError("нет списка контрольных сумм страниц")
        except (OSError, TypeError, ValueError, KeyError) as exc:
            raise BuildError(f"Не читается предыдущий preflight.json: {exc}") from exc

    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".workbook-", dir=output.parent) as scratch:
        staged = Path(scratch) / "result"
        staged.mkdir()
        pdf = staged / "book.pdf"
        document.write_pdf(pdf, finisher=add_crop_marks if marks else None)
        fonts = validate_pdf(pdf, ctx, print_mode, marks)
        hashes, changed = make_sheets(pdf, staged, ctx.total, previous)
        warnings = display(ctx.warnings) + handler.warnings
        report = {
            "format": ctx.book["format"],
            "pages": ctx.total,
            "mode": "print" if print_mode else "preview",
            "bleed_mm": tokens["print"]["bleed"] if print_mode else 0,
            "crop_marks": marks,
            "fonts": fonts,
            "warnings": warnings,
            "page_sha256": hashes,
        }
        if previous is not None:
            report["changed_pages"] = changed
            report["removed_pages"] = list(range(ctx.total + 1, len(previous) + 1))
        (staged / "preflight.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        publish(staged, output)
    return BuildResult(ctx.total, warnings)


def main():
    parser = argparse.ArgumentParser(description="Собрать PDF тетради и листы проверки.")
    parser.add_argument("book", help="имя папки внутри books")
    parser.add_argument("--print", dest="print_mode", action="store_true", help="собрать с вылетами")
    parser.add_argument("--marks", action="store_true", help="добавить метки реза в печатный PDF")
    parser.add_argument("--compare", type=Path, metavar="PREFLIGHT", help="сравнить с предыдущим preflight.json")
    args = parser.parse_args()
    if not re.fullmatch(r"[\w-]+", args.book) or (args.marks and not args.print_mode):
        parser.error("Укажи имя папки внутри books. Для меток реза нужен --print.")
    output = ROOT / "out" / args.book / ("print" if args.print_mode else "preview")
    try:
        result = build(ROOT / "books" / args.book, output, read_tokens(),
                       print_mode=args.print_mode, marks=args.marks, compare=args.compare)
    except (BuildError, OSError) as exc:
        print(f"Сборка остановлена.\n{exc}", file=sys.stderr)
        return 1
    print(f"Страниц: {result.pages}. PDF, листы и отчёт: {output}")
    for warning in result.warnings:
        print(f"Проверь: {warning}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
