# Student ImageGen Enforcer

Portable Codex skill for students. It forces visual tasks through Codex's
built-in `$imagegen` / platform-native imagegen route instead of letting the
agent fake visuals with SVG, CSS gradients, canvas, Python drawings, or
placeholder boxes.

## Install

Unzip the package into the Codex skills directory:

```bash
mkdir -p "$HOME/.codex/skills"
unzip -o student-imagegen-enforcer.zip -d "$HOME/.codex/skills"
```

After installation, the file should exist here:

```text
$HOME/.codex/skills/student-imagegen-enforcer/SKILL.md
```

Restart Codex or open a new task so the skill list refreshes.

## How To Use

In a task, write one of these:

```text
Use student-imagegen-enforcer. Create a square image: a premium desk setup for a
small business owner using AI tools, realistic photo style, no readable text.
Save the selected image into ./assets/generated/ and show me the result.
```

```text
Используй student-imagegen-enforcer. Сделай обложку для презентации про AI
ассистентов в бизнесе, дорогой современный стиль, без текста на картинке.
```

```text
Сделай визуал для первого экрана лендинга: российский предприниматель управляет
AI-ассистентами в рабочем кабинете, дорогой реалистичный стиль, без текста на
картинке.
```

```text
Нарисуй концепт интерфейса интерактивного дашборда для руководителя: метрики,
задачи, AI-ассистенты, спокойный дорогой SaaS-стиль, без читаемого текста.
```

```text
Сделай концепт экрана мобильного приложения для записи клиентов: современный
интерфейс, чистая композиция, без читаемого текста.
```

The expected result is a real generated image produced through built-in
imagegen. If imagegen is unavailable, the agent must stop and say so instead of
creating a fake placeholder.

## What Counts As Failure

- The agent creates only an HTML block, SVG illustration, CSS gradient, canvas
  drawing, or Python-generated picture.
- The agent calls an Image API or CLI directly instead of using built-in
  `$imagegen` / platform-native imagegen.
- The generated asset is not saved into the project when it is part of a site,
  deck, PDF, or app.
- The final artifact references an image that was not visually checked.
