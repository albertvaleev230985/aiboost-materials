---
name: student-imagegen-enforcer
description: Use when the user asks to generate, edit, visualize, illustrate, render, draw, sketch, mock up, or create any image, picture, photo, photograph, visual asset, hero image, cover, poster, social card, thumbnail, banner, logo concept, avatar, product mockup, presentation visual, slide image, website visual, landing-page visual, interactive dashboard visual, dashboard UI mockup, app interface concept, app screen, mobile app screen, web app screen, UI screenshot, interface illustration, icon, game asset, reference image, картинка, изображение, фото, визуал, иллюстрация, нарисуй, сгенерируй картинку, сделай визуал, мокап, обложка, постер, креатив, ассет, фон, герой, баннер, логотип, аватар, миниатюра, превью, презентация, слайд, визуал для сайта, лендинг, интерактивный дашборд, интерфейс приложения, экран приложения, скриншот интерфейса, UI, UX. This skill forces Codex to use the built-in $imagegen / platform-native imagegen route for bitmap visuals instead of SVG, CSS, canvas, Python drawing, placeholder gradients, or direct API calls.
---

# Student ImageGen Enforcer

## Purpose

Use this skill whenever the task needs a real generated or edited visual.

The goal is simple: visual work must go through Codex's built-in image
generation route, called `$imagegen` or platform-native `imagegen`.
Do not replace it with code-drawn placeholders.

## Hard Rule

For every bitmap visual asset, use `$imagegen` / platform-native `imagegen`.

Before generating or editing an image, load and follow the installed image
generation skill when it is available:

```text
${CODEX_HOME:-$HOME/.codex}/skills/.system/imagegen/SKILL.md
```

If that system skill file is not visible in the filesystem but `$imagegen`,
`imagegen`, or the platform-native image generation tool is available in the
current Codex surface, use that built-in route directly.

Do not call any image-generation API directly, including OpenAI, Replicate,
Stability, Ideogram, Flux, Midjourney, or other providers. Do not use an image
CLI, Python, SVG, canvas, HTML/CSS gradients, CSS blobs, ASCII art, placeholder
boxes, stock placeholder services, or one-off raster scripts as a substitute for
generated visuals.

If no built-in image generation route is available, stop and tell the user that
image generation is unavailable in this Codex environment. Ask them to enable or
open Codex with built-in image generation instead of faking the visual.

## Triggered Tasks

Use this skill for:

- generating a new image, cover, poster, banner, hero, background, social card,
  thumbnail, logo concept, avatar, product mockup, UI mockup, icon, game asset,
  illustration, scene, texture, or visual reference
- editing an attached image, screenshot, logo draft, photo, generated image, or
  visual reference
- building a presentation, slide deck, landing page, proposal, PDF, article,
  handout, course page, or website where image quality matters
- designing or illustrating an interactive dashboard, admin panel, analytics
  screen, CRM screen, SaaS workspace, mobile app, web app, marketplace, form,
  calculator, configurator, or any other software interface
- creating a visual direction for an app before implementation: interface
  concept, app screen, UI screenshot-style mockup, onboarding screen, empty
  state, settings screen, data dashboard, or product demo scene
- replacing weak placeholders with real visual assets

If the user asks for a full artifact such as a landing page or presentation,
first decide which parts need real bitmap visuals, then generate those visuals
with `$imagegen` before final assembly.

If the user asks to build a working app, dashboard, or site, do not replace the
working product with a static image. Build the real interface in code, but use
`$imagegen` for visual references, hero images, mockups, textures, product
scenes, empty-state art, screenshots-as-concepts, or other bitmap assets that
make the interface look intentional.

## Prompt Contract

Every `$imagegen` request must include:

- asset type and final use
- subject and key details
- aspect ratio or intended placement
- composition and framing
- style, material, lighting, and palette
- reference image roles, if any
- constraints and avoid list
- whether the output must contain no readable text

Keep readable interface text, slide titles, labels, numbers, tables, code, and
brand copy outside the generated bitmap whenever possible. Put that content in
editable HTML, slide, document, or design layers.

## Reference Images

When the user provides images, classify each one before generation:

- edit target: the image to change
- reference image: identity, subject, object, or environment to preserve
- style reference: mood, palette, composition, or treatment to borrow
- compositing input: image that must be combined with generated material

Attach the relevant images to `$imagegen` whenever the current route supports
references. Do not describe a critical reference only in text when the image can
be attached.

## Asset Persistence

For project work, save the selected generated images inside the project, near
the artifact that uses them. Prefer paths such as:

```text
assets/generated/
public/generated/
images/generated/
```

Do not leave final project assets only in Codex's temporary generated-images
cache.

## Verification

After generation:

1. Inspect the generated image visually.
2. Confirm it matches the requested subject, composition, and constraints.
3. If the image is used inside a page, deck, PDF, or app, open or screenshot the
   final artifact and confirm the image actually loads.
4. Replace failed generations through `$imagegen`; do not patch a failed visual
   with code-drawn decoration.

## Student-Friendly Refusal

If a request would normally need a generated image but `$imagegen` is not
available, say:

```text
I need the built-in Codex image generation route for this visual task, but it is
not available in this environment. I will not fake the result with SVG, CSS, or
Python placeholders. Please enable/open Codex with built-in image generation and
run this request again.
```

## Quick Test Prompt

After installing this skill, test it with:

```text
Use student-imagegen-enforcer. Create a square image: a premium desk setup for a
small business owner using AI tools, realistic photo style, no readable text.
Save the selected image into ./assets/generated/ and show me the result.
```

The correct behavior is a real generated image. A CSS/SVG/Python placeholder is
a failed run.
