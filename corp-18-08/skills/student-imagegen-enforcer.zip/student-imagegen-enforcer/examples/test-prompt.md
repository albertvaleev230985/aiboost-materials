# Test Prompt

Prompt 1, explicit skill call:

Use student-imagegen-enforcer. Create a square image: a premium desk setup for a
small business owner using AI tools, realistic photo style, calm expensive
lighting, graphite and warm metal accents, no readable text. Save the selected
image into ./assets/generated/ and show me the result.

Prompt 2, automatic trigger check:

Нарисуй концепт интерфейса интерактивного дашборда для собственника малого
бизнеса: метрики, задачи, AI-ассистенты, дорогой спокойный SaaS-стиль, без
читаемого текста. Сохрани выбранную картинку в ./assets/generated/.

Prompt 3, refusal check when imagegen is unavailable:

If built-in imagegen is unavailable in this Codex environment, do not create any
SVG, CSS, canvas, Python, or placeholder visual. Stop and explain that built-in
image generation is required.

Correct behavior: Codex uses built-in `$imagegen` / platform-native imagegen and
returns a real generated image. It must not create an SVG, CSS gradient, canvas
drawing, Python drawing, or placeholder box.
